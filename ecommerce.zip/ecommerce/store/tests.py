from django.test import TestCase

from django.test import TestCase
from django.urls import reverse

class HomepageTests(TestCase):

    def test_homepage_title(self):
        """Test that the homepage title is correct."""
        response = self.client.get(reverse('home'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Selamat Datang di Website Kami.")

    def test_homepage_welcome_message(self):
        """Test that the homepage welcome message is displayed."""
        response = self.client.get(reverse('home'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Silahkan Cari Apapun Yang Kalian Inginkan")

    def test_homepage_create_account_button(self):
        """Test that the "Create an account" button is present."""
        response = self.client.get(reverse('home'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Create an account")

    def test_homepage_products_section(self):
        """Test that the "All products" section is present"""