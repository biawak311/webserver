from django.shortcuts import render

from . models import Category, Product

from django.shortcuts import get_object_or_404
from django.http import JsonResponse
from .models import Product

def store(request):

    all_products = Product.objects.all()

    context = {'my_products':all_products}

    return render(request, 'store/store.html', context)



def categories(request):

    all_categories = Category.objects.all()

    return {'all_categories': all_categories}



def list_category(request, category_slug=None):

    category = get_object_or_404(Category, slug=category_slug)

    products = Product.objects.filter(category=category)


    return render(request, 'store/list-category.html', {'category':category, 'products':products})



def product_info(request, product_slug):

    product = get_object_or_404(Product, slug=product_slug)

    context = {'product': product}

    return render(request, 'store/product-info.html', context)


def get_popular_products(request):
    # Ambil data produk populer (contoh: berdasarkan jumlah penjualan)
    popular_products = Product.objects.filter(is_popular=True)[:5]  # Limit 5
    data = [
        {
            'id': product.id,
            'name': product.name,
            'price': product.price,
            'image': product.image.url if product.image else None,
        }
        for product in popular_products
    ]
    return JsonResponse({'popular_products': data})




